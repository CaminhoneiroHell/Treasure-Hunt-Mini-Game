using System.Collections.Generic;
using UnityEngine;

namespace TreasureHuntMiniGame
{
    public class RewardManager : MonoBehaviour
    {
    
        public void AwardRandomReward()
        {
        }
    }
}